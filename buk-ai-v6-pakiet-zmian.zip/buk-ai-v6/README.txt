BUK AI 6.0 — darmowy prototyp automatycznych propozycji

1. Wgraj wszystkie pliki i foldery do repozytorium GitHub grzegorzpempera/buk-ai.
2. GitHub Actions -> BUK AI - darmowe zestawienie dzienne -> Run workflow.
3. Settings -> Actions -> General -> Workflow permissions: Read and write permissions (jeśli wymagane).
4. Otwórz https://grzegorzpempera.github.io/buk-ai/analiza.html
5. W razie braku raportu sprawdź zakładkę Actions (błędy i uprawnienia).

Uwaga: GitHub Pages nie wykonuje skryptów Python. GitHub Actions tworzy data/daily.json codziennie, zwykle około 07:15 UTC, ale harmonogram może być opóźniony.
Dane z ESPN to terminarze i bilanse, nie kursy bukmacherskie. Kursy orientacyjne są wyliczane z nieskalibrowanego wskaźnika, nie są cenami rynku ani obietnicą wartości zakładu. Nie wyciągamy typów z zawodtyper.pl ani YouTube: wymagają odrębnych zgodnych z regulaminem integracji.
Brak wystarczających danych oznacza brak kuponów, nie uzupełniamy ich fikcją.
Wersja 6.0 przechowuje zapisane rzeczywiste kursy lokalnie w przeglądarce, niezależnie od historii v5. Bez synchronizacji między urządzeniami.

NOWE: import.html — import kuponu Superbet ze zdjęcia z OCR (Tesseract.js, ładowany z CDN). Zdjęcie jest przetwarzane lokalnie, tekst i dane zapisują się w localStorage. Zdjęcie nie jest archiwizowane. OCR wymaga weryfikacji; nie gwarantuje poprawności pól. Dane importu są osobno od historii starszych wersji. Link z analiza.html.
UWAGA: automatyczne analizy obejmują obecnie tylko wybrane ligi piłkarskie, NBA i NHL. Tenis, dart, źródła typerskie i rynkowe kursy nie są zintegrowane. Workflow może nie generować kuponów, jeśli brak danych.
